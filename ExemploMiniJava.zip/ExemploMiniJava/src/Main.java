
import ast.Program;
import java.io.FileReader;
import java.nio.file.Paths;

public class Main {
    public static void main(String []args){
        String rootPath = Paths.get("").toAbsolutePath().toString();
        String subPath = "\\src\\samples\\";

        String sourcecode = rootPath + subPath + "Exemplo";
        
        try {
            Parser p = new Parser(new LexicalAnalyzer(new FileReader(sourcecode)));
            Program result = (Program) p.parse().value;
            System.out.println("\nAST:\n" + result.toString());

            
            
            
            
            
            System.out.println("Compilacao concluida com sucesso...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
